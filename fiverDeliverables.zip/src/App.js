import Routes from './Routes';

function App() {
  return (
    <main>
      <div>
        <Routes />
      </div>
    </main>
  );
}

export default App;
